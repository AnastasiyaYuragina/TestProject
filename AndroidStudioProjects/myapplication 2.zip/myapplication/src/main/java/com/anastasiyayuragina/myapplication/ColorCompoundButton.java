package com.anastasiyayuragina.myapplication;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CompoundButton;

/**
 * Created by anastasiyayuragina on 7/6/16.
 */
public class ColorCompoundButton extends CompoundButton {

    public ColorCompoundButton(Context context) {
        this(context, null);
    }

    public ColorCompoundButton(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ColorCompoundButton(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {

        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }

}
