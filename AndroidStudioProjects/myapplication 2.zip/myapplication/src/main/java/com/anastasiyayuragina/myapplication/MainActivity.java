package com.anastasiyayuragina.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.ToggleButton;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import java.util.ArrayList;


public class MainActivity extends Activity{

    private static final String TAG = "MainActivity";
    private LinearLayout linearColorSelector;
    private TableLayout tableLayoutTextSelector;
    private EditText editCustomText;
    private Button buttonClearText;
    private String colorString = "";
    private String textString = "";
    private ArrayList<ColorCompoundButton> colorCompoundButtonArrayList = new ArrayList<>();
    private ArrayList<ToggleButton> textToggleButtonArrayList = new ArrayList<>();
    private Tracker mTracker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AnalyticsApplication application = (AnalyticsApplication) getApplication();
        mTracker = application.getDefaultTracker();

        linearColorSelector = (LinearLayout) findViewById(R.id.linear_color_selector);
        tableLayoutTextSelector = (TableLayout) findViewById(R.id.table_layout_text_selector);
        editCustomText = (EditText) findViewById(R.id.edit_custom_text);
        buttonClearText = (Button) findViewById(R.id.button_clear_text);

        for (int i = 0; i < linearColorSelector.getChildCount(); i++) {

            ColorCompoundButton colorCompoundButton = (ColorCompoundButton) linearColorSelector.getChildAt(i);

            colorCompoundButton.setOnCheckedChangeListener(colorListener);
            colorCompoundButtonArrayList.add(colorCompoundButton);
        }

        for (int i = 0; i < tableLayoutTextSelector.getChildCount(); i++) {

            TableRow tableRow = (TableRow) tableLayoutTextSelector.getChildAt(i);

            for (int j = 0; j < tableRow.getChildCount(); j++) {
                ToggleButton textToggleButton = (ToggleButton) tableRow.getChildAt(j);

                textToggleButton.setOnCheckedChangeListener(textListenerCheck());
                textToggleButtonArrayList.add(textToggleButton);
            }
        }

        editCustomText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (ToggleButton text : textToggleButtonArrayList) {
                    text.setChecked(false);
                }
            }
        });

        editCustomText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                editCustomText.setGravity(View.TEXT_ALIGNMENT_GRAVITY);
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (editCustomText.getText().toString().isEmpty()) {
                    changedColor(editCustomText, getResources().getColor(R.color.BFFF), getResources().getDrawable(R.drawable.rectangle_rounded));
                    editCustomText.setGravity(View.TEXT_ALIGNMENT_VIEW_END);
                    textString = "";
                } else {
                    textString = editCustomText.getText().toString();
                }
            }
        });

        buttonClearText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editCustomText.setText("");
                if (editCustomText.getText().toString().isEmpty()) {
                    changedColor(editCustomText, getResources().getColor(R.color.BFFF), getResources().getDrawable(R.drawable.rectangle_rounded));
                }
            }
        });

        editCustomText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean handled = false;
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    if (editCustomText.getText().toString().isEmpty()) {
                        changedColor(editCustomText, getResources().getColor(R.color.BFFF), getResources().getDrawable(R.drawable.rectangle_rounded));
                        textString = "";
                    } else {
                        for (ToggleButton text : textToggleButtonArrayList) {
                            text.setChecked(false);
                        }
                        changedColor(editCustomText, getResources().getColor(R.color.black), getResources().getDrawable(R.drawable.custom_text_selector));
                        textString = editCustomText.getText().toString();
                        if (!colorString.isEmpty()) {
                            mTracker.setScreenName("Selected text & color");
                            mTracker.send(new HitBuilders.ScreenViewBuilder().build());
                            mTracker.send(new HitBuilders.EventBuilder().setCategory("Custom text").setAction(colorString).build());

                            Intent intent = new Intent(MainActivity.this, FlashingActivity.class);
                            intent.putExtra("color", colorString);
                            intent.putExtra("text", textString);
                            startActivity(intent);
                        }
                    }
                    Log.d(TAG, "start hide keyboard");
                    InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    inputMethodManager.hideSoftInputFromWindow(editCustomText.getWindowToken(), 0);

                    editCustomText.clearFocus();

                    //redirect to flashing screen
                    handled = true;
                }
                return handled;
            }
        });

    }

    private CompoundButton.OnCheckedChangeListener colorListener = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton colorCompoundButton, boolean check) {
            if (!check) {
                colorString = "";
            } else {
                for (ColorCompoundButton color : colorCompoundButtonArrayList) {
                    if (colorCompoundButton != color) {
                        color.setChecked(false);
                    }
                }
                colorString = (String) colorCompoundButton.getTag();
                if (!textString.isEmpty()) {
                    mTracker.setScreenName("Selected text & color");
                    mTracker.send(new HitBuilders.ScreenViewBuilder().build());
                    mTracker.send(new HitBuilders.EventBuilder().setCategory(textString).setAction(colorString).build());

                    Intent intent = new Intent(MainActivity.this, FlashingActivity.class);
                    intent.putExtra("color", colorString);
                    intent.putExtra("text", textString);
                    startActivity(intent);
                }
            }
        }
    };

    private CompoundButton.OnCheckedChangeListener textListenerCheck() {
        return new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton textCompoundButton, boolean check) {
                if (!check) {
                    textString = "";
                    changedColor(textCompoundButton, getResources().getColor(R.color.BFFF));
                } else {
                    Log.d(TAG, "start hide keyboard");
                    InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    inputMethodManager.hideSoftInputFromWindow(editCustomText.getWindowToken(), 0);

                    editCustomText.clearFocus();

                    changedColor(editCustomText, getResources().getColor(R.color.BFFF), getResources().getDrawable(R.drawable.rectangle_rounded));
                    for (ToggleButton text : textToggleButtonArrayList) {
                        if (textCompoundButton != text) {
                            text.setChecked(false);
                        }
                    }
                    changedColor(textCompoundButton, getResources().getColor(R.color.black));
                    textString = textCompoundButton.getTag().toString();
                    if (!colorString.isEmpty()) {
                        mTracker.setScreenName("Selected text & color");
                        mTracker.send(new HitBuilders.ScreenViewBuilder().build());
                        mTracker.send(new HitBuilders.EventBuilder().setCategory(textString).setAction(colorString).build());

                        Intent intent = new Intent(MainActivity.this, FlashingActivity.class);
                        intent.putExtra("color", colorString);
                        intent.putExtra("text", textString);
                        startActivity(intent);
                    }
                }
            }
        };
    }

    private void changedColor (TextView someElemant, int color) {
        someElemant.setTextColor(color);
    }

    private void changedColor (TextView someElemant, int colorText, Drawable colorBackground) {
        someElemant.setTextColor(colorText);
        someElemant.setBackground(colorBackground);
    }

    @Override
    protected void onResume() {
        super.onResume();

        for (ToggleButton text : textToggleButtonArrayList) {
                text.setChecked(false);
        }

        for (ColorCompoundButton color : colorCompoundButtonArrayList) {
                color.setChecked(false);
            }
        editCustomText.setText("");
        textString = "";
        colorString = "";
    }
}
